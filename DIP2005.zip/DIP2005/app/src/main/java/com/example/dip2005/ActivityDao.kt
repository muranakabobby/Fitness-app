package com.example.dip2005

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityDao {

    @Query("SELECT * FROM activities ORDER BY id DESC")
    fun getAllFlow(): Flow<List<Activity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(activity: Activity): Long

    @Update
    suspend fun update(activity: Activity)

    @Query("DELETE FROM activities WHERE id = :activityId")
    suspend fun deleteById(activityId: Int)

    @Query("DELETE FROM activities")
    suspend fun deleteAll()
}