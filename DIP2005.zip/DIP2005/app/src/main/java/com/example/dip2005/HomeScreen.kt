package com.example.dip2005

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun HomeScreen(navController: NavHostController) {
    val windowSize = rememberWindowSize()
    val adaptivePadding = getAdaptivePadding()
    val isLandscape = isLandscape()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.surface
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(adaptivePadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = if (isLandscape) Arrangement.Top else Arrangement.Center
        ) {
            if (!isLandscape) {
                Spacer(modifier = Modifier.height(24.dp))
            }

            // App Title
            Text(
                text = "SmartFit",
                style = when (windowSize) {
                    WindowSize.COMPACT -> MaterialTheme.typography.displayMedium
                    WindowSize.MEDIUM -> MaterialTheme.typography.displayLarge
                    WindowSize.EXPANDED -> MaterialTheme.typography.displayLarge
                },
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "Your Fitness Journey Starts Here",
                style = when (windowSize) {
                    WindowSize.COMPACT -> MaterialTheme.typography.bodyLarge
                    else -> MaterialTheme.typography.titleLarge
                },
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            Spacer(modifier = Modifier.height(
                if (isLandscape) 24.dp else 48.dp
            ))

            // Navigation Cards
            NavigationCard(
                title = "Activity Log",
                description = "Track your workouts",
                icon = Icons.Default.Star,
                onClick = { navController.navigate("activity") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            NavigationCard(
                title = "Fitness Tips",
                description = "Get healthy advice",
                icon = Icons.Default.Info,
                onClick = { navController.navigate("tips") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            NavigationCard(
                title = "Profile",
                description = "Manage your settings",
                icon = Icons.Default.Person,
                onClick = { navController.navigate("profile") }
            )
        }
    }
}

@Composable
fun NavigationCard(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Navigate",
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        }
    }
}
