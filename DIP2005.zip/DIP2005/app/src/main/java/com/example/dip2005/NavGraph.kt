package com.example.dip2005

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument

@Composable
fun AppNav(navController: NavHostController) {
    NavHost(navController, startDestination = "welcome") {

        // Welcome/Splash Screen - Entry point
        composable("welcome") {
            WelcomeScreen(navController)
        }

        // Home Screen
        composable("home") {
            HomeScreen(navController)
        }

        // Activity Log Screen
        composable("activity") {
            ActivityLogScreen(navController)
        }

        // Activity Detail Screen with data passing
        composable(
            route = "activityDetail/{activityId}",
            arguments = listOf(
                navArgument("activityId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val activityId = backStackEntry.arguments?.getInt("activityId") ?: 0
            ActivityDetailScreen(navController, activityId)
        }

        // Tips Screen
        composable("tips") {
            TipsScreen(navController)
        }

        // Profile Screen
        composable("profile") {
            ProfileScreen(navController)
        }
    }
}
