package com.example.dip2005

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

data class FitnessTip(
    val icon: ImageVector,
    val title: String,
    val description: String,
    val color: Color
)

@Composable
fun TipsScreen(navController: NavHostController) {
    val windowSize = rememberWindowSize()
    val adaptivePadding = getAdaptivePadding()

    val tips = listOf(
        FitnessTip(
            icon = Icons.Default.Info,
            title = "Stay Hydrated",
            description = "Drink at least 8 glasses of water daily to keep your body energized",
            color = Color(0xFF2196F3)
        ),
        FitnessTip(
            icon = Icons.Default.Check,
            title = "Daily Steps",
            description = "Walk 10,000 steps daily to maintain cardiovascular health",
            color = Color(0xFF4CAF50)
        ),
        FitnessTip(
            icon = Icons.Default.CheckCircle,
            title = "Morning Stretch",
            description = "Stretch every morning to improve flexibility and reduce injury risk",
            color = Color(0xFFFF9800)
        ),
        FitnessTip(
            icon = Icons.Default.Star,
            title = "Quality Sleep",
            description = "Get 7-8 hours of sleep for optimal recovery and performance",
            color = Color(0xFF9C27B0)
        ),
        FitnessTip(
            icon = Icons.Default.Star,
            title = "Balanced Diet",
            description = "Eat a variety of fruits, vegetables, and proteins for nutrition",
            color = Color(0xFFE91E63)
        ),
        FitnessTip(
            icon = Icons.Default.Favorite,
            title = "Regular Exercise",
            description = "Aim for 150 minutes of moderate activity per week",
            color = Color(0xFFFF5722)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary,
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(adaptivePadding)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = { navController.popBackStack() },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Column {
                        Text(
                            text = "Fitness Tips",
                            style = when (windowSize) {
                                WindowSize.COMPACT -> MaterialTheme.typography.headlineMedium
                                WindowSize.MEDIUM -> MaterialTheme.typography.headlineLarge
                                WindowSize.EXPANDED -> MaterialTheme.typography.headlineLarge
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Text(
                            text = "Expert advice for a healthier you",
                            style = when (windowSize) {
                                WindowSize.COMPACT -> MaterialTheme.typography.bodyMedium
                                else -> MaterialTheme.typography.bodyLarge
                            },
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Tips List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(adaptivePadding),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tips) { tip ->
                TipCard(tip)
            }
        }
    }
}

@Composable
fun TipCard(tip: FitnessTip) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon Container
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(tip.color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tip.icon,
                    contentDescription = null,
                    modifier = Modifier.size(32.dp),
                    tint = tip.color
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text Content
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tip.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = tip.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}
