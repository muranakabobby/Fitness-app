package com.example.dip2005

import kotlinx.coroutines.flow.Flow

interface ActivityRepository {
    fun getAllActivitiesFlow(): Flow<List<Activity>>
    suspend fun insertActivity(activity: Activity): Long
    suspend fun updateActivity(activity: Activity)
    suspend fun deleteActivity(activityId: Int)
    suspend fun deleteAllActivities()
    suspend fun getThemeIsDark(): Boolean
    suspend fun saveThemeIsDark(isDark: Boolean)
}

