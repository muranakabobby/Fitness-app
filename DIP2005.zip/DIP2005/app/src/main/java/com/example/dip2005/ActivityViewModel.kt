package com.example.dip2005

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ActivityViewModel(private val repository: ActivityRepository) : ViewModel() {

    val activities: StateFlow<List<Activity>> = repository.getAllActivitiesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addActivity(activity: Activity) = viewModelScope.launch {
        repository.insertActivity(activity)
    }

    fun updateActivity(activity: Activity) = viewModelScope.launch {
        repository.updateActivity(activity)
    }

    fun deleteActivity(id: Int) = viewModelScope.launch {
        repository.deleteActivity(id)
    }

    fun deleteAllActivities() = viewModelScope.launch {
        repository.deleteAllActivities()
    }

    suspend fun isDarkTheme(): Boolean {
        return repository.getThemeIsDark()
    }

    fun saveThemePreference(isDark: Boolean) = viewModelScope.launch {
        repository.saveThemeIsDark(isDark)
    }
}

class ActivityViewModelFactory(private val repository: ActivityRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ActivityViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ActivityViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
