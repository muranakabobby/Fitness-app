package com.example.dip2005

import android.content.Context
import androidx.room.Room

object ServiceLocator {

    private var dbInstance: AppDatabase? = null
    private var repoInstance: ActivityRepository? = null

    fun provideDatabase(context: Context): AppDatabase {
        return dbInstance ?: synchronized(this) {
            val db = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "smartfit-db"
            )
                .fallbackToDestructiveMigration()
                .build()

            dbInstance = db
            db
        }
    }

    fun provideRepository(context: Context): ActivityRepository {
        return repoInstance ?: synchronized(this) {
            val repo = RoomActivityRepository(
                provideDatabase(context),
                context.applicationContext
            )
            repoInstance = repo
            repo
        }
    }
}
