package com.example.dip2005

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map


private val Context.dataStore by preferencesDataStore("user_prefs")

class RoomActivityRepository(
    private val db: AppDatabase,
    private val context: Context
) : ActivityRepository {

    private val dao = db.activityDao()



    override fun getAllActivitiesFlow() = dao.getAllFlow()

    override suspend fun insertActivity(activity: Activity): Long {
        return dao.insert(activity)
    }

    override suspend fun updateActivity(activity: Activity) {
        dao.update(activity)
    }

    override suspend fun deleteActivity(activityId: Int) {
        dao.deleteById(activityId)
    }

    override suspend fun deleteAllActivities() {
        dao.deleteAll()
    }

    private val THEME_KEY = booleanPreferencesKey("theme_dark")

    override suspend fun getThemeIsDark(): Boolean {
        return context.dataStore.data
            .map { prefs -> prefs[THEME_KEY] ?: false }
            .first()
    }

    override suspend fun saveThemeIsDark(isDark: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[THEME_KEY] = isDark
        }
    }
}
